package no.hvl.dat102;

public class Kalkulator {
	//Kalkulator

	public static int add(int tall1, int tall2) {
		return tall1 + tall2;
	}

	public static int sub(int tall1, int tall2) {
		return tall1 - tall2;
	}
	
	
	public static int mul(int tall1, int tall2) {
		return tall1 * tall2;
	}

	public static int div(int tall1, int tall2) {
		return tall1 / tall2;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

	}

}
