package no.hvl.dat102.listeklient;

public class KlientTurnering {
 /*****************************************************************
   
 *****************************************************************/
 public static void main (String[] args ) {
	 Turnering turnering = new Turnering();
	 turnering.settOpp();
 } 
}
