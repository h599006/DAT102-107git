package no.hvl.dat102.adt;

public interface ParADT<T> {
	public void bytte();

	public T maks();

}
